from .wpfast import *

__doc__ = wpfast.__doc__
if hasattr(wpfast, "__all__"):
    __all__ = wpfast.__all__